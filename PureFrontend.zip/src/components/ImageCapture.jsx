import React, { useState, useRef } from 'react';
import Webcam from 'react-webcam';
import { X, Upload, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const ImageCapture = ({ isOpen, onClose, mode, onAnalysisComplete }) => {
  const [imagePreview, setImagePreview] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null)
   const Auth = useAuth(); 
  
  const webcamRef = useRef(null);
  const fileInputRef = useRef(null);

  const videoConstraints = {
    width: { ideal: 1920 },
    height: { ideal: 1080 },
    facingMode: mode === 'scan' ? 'environment' : 'user',
  };

  const handleCapture = () => {
    if (webcamRef.current) {
      const video = webcamRef.current.video;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageSrc = canvas.toDataURL('image/jpeg', 1);
      setImagePreview(imageSrc);
      setShowConfirmation(true);
      setError(null);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size should be less than 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target.result);
        setShowConfirmation(true);
        setError(null);
      };
      reader.onerror = () => {
        setError('Error reading file');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!imagePreview) return;
    
    setIsAnalyzing(true);
    setError(null);
  
    const TIMEOUT_DURATION = 30000;
    const MAX_RETRIES = 3;
    
    const fetchWithTimeout = async (formData) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_DURATION);
      
      try {
        const response = await fetch(`${import.meta.env.VITE_BASE_URL}/process/analysis`, {
          method: 'POST',
          body: formData,
          headers: {
            'Authorization': `Bearer ${Auth.user.token}`
          },
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
        }
        
        return await response.json();
      } catch (error) {
        console.error('Fetch error:', error);
        throw error;
      } finally {
        clearTimeout(timeoutId);
      }
    };
  
    const analyzeWithRetry = async () => {
      for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
          const formData = new FormData();
          
          // Remove the data:image/jpeg;base64, prefix if it exists
          const base64Data = imagePreview.replace(/^data:image\/\w+;base64,/, '');
          
          // Convert base64 to Blob
          const byteCharacters = atob(base64Data);
          const byteArrays = [];
          
          for (let offset = 0; offset < byteCharacters.length; offset += 512) {
            const slice = byteCharacters.slice(offset, offset + 512);
            const byteNumbers = new Array(slice.length);
            
            for (let i = 0; i < slice.length; i++) {
              byteNumbers[i] = slice.charCodeAt(i);
            }
            
            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }
          
          const blob = new Blob(byteArrays, { type: 'image/jpeg' });
          
          // Append the blob with the correct field name
          formData.append('images', blob, 'image.jpg');  // Changed from 'images' to 'image'
          
          const data = await fetchWithTimeout(formData);
          return data;
        } catch (error) {
          console.error(`Attempt ${attempt} failed:`, error);
          
          if (error.name === 'AbortError') {
            setError(`Request timeout (Attempt ${attempt}/${MAX_RETRIES})`);
          } else {
            setError(`Analysis failed (Attempt ${attempt}/${MAX_RETRIES}): ${error.message}`);
          }
          
          if (attempt === MAX_RETRIES) throw error;
          
          await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt)));
        }
      }
    };
  
    try {
      const result = await analyzeWithRetry();
      if (result) {
        onAnalysisComplete?.(result);
        handleClose();
      }
    } catch (error) {
      console.error('Final error:', error);
      setError(`Analysis failed after ${MAX_RETRIES} attempts: ${error.message}`);
    } finally {
      setIsAnalyzing(false);
    }
  };
  
    
  

  const handleClose = () => {
    setImagePreview(null);
    setShowConfirmation(false);
    setError(null);
    setAnalysisResult(null);
    onClose();
  };

  const handleRetake = () => {
    setImagePreview(null);
    setShowConfirmation(false);
    setError(null);
    setAnalysisResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return isOpen ? (
    // Style and UI improvements for ImageCapture component
// Only the changed parts are shown

// In the return statement, replace the fixed inset-0 div with this enhanced version:
<div className="fixed inset-0 z-50 bg-gradient-to-b from-black to-gray-900 text-white">
  <div className="relative h-full flex flex-col">
    {/* Enhanced Header */}
    <div className="p-4 flex justify-between items-center bg-black/80 backdrop-filter backdrop-blur-sm">
      <button onClick={handleClose} className="text-white p-2 hover:bg-gray-800/50 rounded-full transition-colors">
        <X className="w-6 h-6" />
      </button>
      <h2 className="text-white font-medium text-lg">
        {mode === 'scan' ? 'Scan Product' : 'Upload Product'}
      </h2>
      <div className="w-10" />
    </div>

    {/* Enhanced Error Display */}
    {error && (
      <div className="bg-red-500/80 backdrop-filter backdrop-blur-sm p-4 flex items-center gap-2 animate-fadeIn">
        <AlertCircle className="w-5 h-5" />
        <span className="font-medium">{error}</span>
      </div>
    )}

    {/* Enhanced Main Content */}
    <div className="flex-1 relative">
      {!imagePreview ? (
        mode === 'scan' ? (
          <div className="relative h-full flex flex-col items-center justify-center">
            <div className="absolute inset-0">
              <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                videoConstraints={videoConstraints}
                className="h-full w-full object-cover"
              />
            </div>
            
            {/* Scan overlay with corners */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-4/5 h-4/5 max-w-md max-h-md border-2 border-white/30 rounded-lg relative">
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-green-500 rounded-tl-lg"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-green-500 rounded-tr-lg"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-green-500 rounded-bl-lg"></div>
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-green-500 rounded-br-lg"></div>
              </div>
            </div>
            
            <button
              onClick={handleCapture}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-colors"
            >
              <div className="w-12 h-12 rounded-full border-4 border-green-500 flex items-center justify-center">
                <div className="w-8 h-8 bg-green-500 rounded-full"></div>
              </div>
            </button>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center p-4 bg-gradient-to-b from-gray-900 to-black">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <div className="mb-8 w-32 h-32 rounded-full bg-gray-800/50 flex items-center justify-center">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-green-500 hover:bg-green-600 p-6 rounded-full mb-4 transition-colors shadow-lg shadow-green-500/20"
              >
                <Upload className="w-8 h-8" />
              </button>
            </div>
            <p className="text-center text-gray-300 max-w-xs">
              Click to upload your product image
              <br />
              <span className="text-sm text-gray-400 block mt-2">
                Supported formats: JPG, PNG (max 5MB)
              </span>
            </p>
          </div>
        )
      ) : (
        <div className="h-full relative">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40 pointer-events-none"></div>
          <img src={imagePreview} alt="Preview" className="h-full w-full object-contain" />
          
          {showConfirmation && (
            <div className="absolute bottom-0 left-0 right-0 bg-black/70 backdrop-filter backdrop-blur-sm p-6">
              <div className="flex justify-between gap-6 max-w-md mx-auto">
                <button
                  onClick={handleRetake}
                  className="flex-1 bg-gray-800 hover:bg-gray-700 text-white py-3 rounded-full transition-colors shadow-lg"
                >
                  Retake
                </button>
                <button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  className={`flex-1 py-3 rounded-full transition-colors shadow-lg ${
                    isAnalyzing ? 'bg-gray-600' : 'bg-green-500 hover:bg-green-600'
                  } text-white font-medium`}
                >
                  {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                </button>
              </div>
              {isAnalyzing && (
                <div className="mt-4 flex justify-center">
                  <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  </div>
</div>
  ) : null;
};

export default ImageCapture;
