module.exports = {
    content: [
      './index.html',
      './src/**/*.{js,jsx}', // Remove 'css' as it is not required here
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  
  console.log('Tailwind is loading...');
  